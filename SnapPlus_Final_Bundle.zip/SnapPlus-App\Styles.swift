import SwiftUI

struct SnapPlusColors {
    static let yellow = Color(red: 255/255, green: 252/255, blue: 0/255)
    static let darkBg = Color(red: 10/255, green: 10/255, blue: 10/255)
    static let cardBg = Color(red: 26/255, green: 26/255, blue: 26/255)
    static let textDim = Color.gray
    static let success = Color.green
}

struct PremiumCardStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding()
            .background(SnapPlusColors.cardBg)
            .cornerRadius(15)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(Color.white.opacity(0.05), lineWidth: 1)
            )
    }
}

extension View {
    func premiumCard() -> some View {
        self.modifier(PremiumCardStyle())
    }
}
