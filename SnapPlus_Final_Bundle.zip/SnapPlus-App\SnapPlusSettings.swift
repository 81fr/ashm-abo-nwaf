import Foundation
import Combine

class SnapPlusSettings: ObservableObject {
    // استخدام مفاتيح عشوائية لتضليل أنظمة الكشف
    private let KEY_SAVE_STORY = "sp_a1x9"
    private let KEY_HIDE_SEEN  = "sp_b2y8"
    private let KEY_SPOOF_LOC  = "sp_c3z7"
    private let KEY_ANTI_BAN   = "sp_d4w6"

    @Published var isSaveStoriesEnabled: Bool {
        didSet { UserDefaults.standard.set(isSaveStoriesEnabled, forKey: KEY_SAVE_STORY) }
    }
    
    @Published var isHideSeenEnabled: Bool {
        didSet { UserDefaults.standard.set(isHideSeenEnabled, forKey: KEY_HIDE_SEEN) }
    }
    
    @Published var isLocationSpoofingEnabled: Bool {
        didSet { UserDefaults.standard.set(isLocationSpoofingEnabled, forKey: KEY_SPOOF_LOC) }
    }
    
    @Published var antiBanProtection: Bool {
        didSet { UserDefaults.standard.set(antiBanProtection, forKey: KEY_ANTI_BAN) }
    }
    
    init() {
        self.isSaveStoriesEnabled = UserDefaults.standard.bool(forKey: KEY_SAVE_STORY)
        self.isHideSeenEnabled = UserDefaults.standard.bool(forKey: KEY_HIDE_SEEN)
        self.isLocationSpoofingEnabled = UserDefaults.standard.bool(forKey: KEY_SPOOF_LOC)
        self.antiBanProtection = UserDefaults.standard.bool(forKey: KEY_ANTI_BAN)
        
        // التحقق من أمان النظام عند التشغيل
        if SecurityShield.checkIntegrity() {
            print("Warning: Debugger detected. Stealth mode activated.")
        }
    }
}
