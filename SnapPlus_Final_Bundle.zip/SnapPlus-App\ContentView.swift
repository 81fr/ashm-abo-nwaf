import SwiftUI

struct ContentView: View {
    @StateObject var settings = SnapPlusSettings()
    
    var body: some View {
        Z shipyard {
            SnapPlusColors.darkBg
                .ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 25) {
                    // Header
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Snap Plus")
                                .font(.system(size: 34, weight: .bold, design: .rounded))
                                .foregroundColor(SnapPlusColors.yellow)
                            Text("النسخة المطورة")
                                .font(.subheadline)
                                .foregroundColor(SnapPlusColors.textDim)
                        }
                        Spacer()
                        Image(systemName: "shield.checkered")
                            .font(.system(size: 30))
                            .foregroundColor(SnapPlusColors.success)
                    }
                    .padding(.top, 20)
                    
                    // Protection Status & Stealth Mode
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Circle()
                                .fill(SnapPlusColors.success)
                                .frame(width: 10, height: 10)
                            Text("نظام التخفي نشط (Stealth Mode)")
                                .font(.footnote)
                                .fontWeight(.bold)
                                .foregroundColor(SnapPlusColors.success)
                            Spacer()
                            Image(systemName: "eyes")
                                .foregroundColor(SnapPlusColors.success)
                        }
                        
                        Divider().background(Color.white.opacity(0.1))
                        
                        VStack(alignment: .leading, spacing: 5) {
                            SecurityRow(label: "تشفير المفاتيح", status: "نشط")
                            SecurityRow(label: "فحص البيئة", status: "آمن")
                            SecurityRow(label: "تعديل البصمة", status: "مكتمل")
                        }
                    }
                    .premiumCard()
                    
                    // Features List
                    VStack(alignment: .leading, spacing: 15) {
                        Text("المميزات")
                            .font(.headline)
                            .padding(.leading, 5)
                        
                        FeatureToggle(title: "حفظ السنابات", icon: "square.and.arrow.down", isOn: $settings.isSaveStoriesEnabled)
                        FeatureToggle(title: "إخفاء مشاهدة الستوري", icon: "eye.slash", isOn: $settings.isHideSeenEnabled)
                        FeatureToggle(title: "تغيير الموقع الجغرافي", icon: "map", isOn: $settings.isLocationSpoofingEnabled)
                        FeatureToggle(title: "درع الحماية المتطور", icon: "bolt.shield", isOn: $settings.antiBanProtection)
                    }
                    
                    // Download & Tools
                    VStack(alignment: .leading, spacing: 15) {
                        Text("أدوات إضافية")
                            .font(.headline)
                            .padding(.leading, 5)
                        
                        Button(action: {}) {
                            HStack {
                                Image(systemName: "trash")
                                Text("تنظيف الكاش")
                                Spacer()
                                Image(systemName: "chevron.left")
                            }
                            .foregroundColor(.white)
                            .premiumCard()
                        }
                    }
                    
                    Spacer(minLength: 50)
                    
                    Text("إصدار 1.0.0 (Build 45)")
                        .font(.caption2)
                        .foregroundColor(SnapPlusColors.textDim)
                        .frame(maxWidth: .infinity, alignment: .center)
                }
                .padding()
            }
        }
    }
}

struct FeatureToggle: View {
    let title: String
    let icon: String
    @Binding var isOn: Bool
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(SnapPlusColors.yellow)
                .frame(width: 30)
            
            Text(title)
                .font(.body)
                .foregroundColor(.white)
            
            Spacer()
            
            Toggle("", isOn: $isOn)
                .toggleStyle(SwitchToggleStyle(tint: SnapPlusColors.yellow))
        }
        .premiumCard()
    }
}

struct SecurityRow: View {
    let label: String
    let status: String
    
    var body: some View {
        HStack {
            Text(label)
                .font(.caption)
                .foregroundColor(SnapPlusColors.textDim)
            Spacer()
            Text(status)
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(SnapPlusColors.success)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
