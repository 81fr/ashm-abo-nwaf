# Snap Plus iOS Project - Source Code

هذا المجلد يحتوي على ملفات البرمجة الخاصة بتطبيق سناب بلس المطور للايفون باستخدام **SwiftUI**.

## كيفية الاستخدام:
1. افتح برنامج **Xcode** على جهاز Mac.
2. قم بإنشاء مشروع جديد: `File > New > Project > iOS > App`.
3. اختر **SwiftUI** كواجهة مستخدم (Interface).
4. استبدل محتويات الملفات التالية في مشروعك بالأكواد الموجودة في هذا المجلد:
   - `ContentView.swift`
   - `SnapPlusSettings.swift`
   - `Styles.swift`
5. تأكد من إعداد **Signing & Capabilities** وربطه بحساب المطور (Apple Developer) الخاص بك.

## الميزات البرمجية:
- **State Management**: استخدام `@StateObject` لإدارة حالة التطبيق.
- **Persistence**: حفظ الإعدادات عبر `UserDefaults`.
- **Dynamic UI**: واجهة متفاعلة تتغير بناءً على حالة نظام الحماية.
