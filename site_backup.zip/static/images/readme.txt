Placeholder for logo.png
